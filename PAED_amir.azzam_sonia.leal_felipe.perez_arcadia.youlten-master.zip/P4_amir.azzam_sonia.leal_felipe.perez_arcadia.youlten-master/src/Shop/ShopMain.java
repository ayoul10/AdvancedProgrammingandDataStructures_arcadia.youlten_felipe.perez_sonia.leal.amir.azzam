package Shop;

import MapObjects.MapObject;
import MapObjects.Point;
import MapObjects.Queue;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ShopMain {

}
